/* ============ THÔNG TIN / TRỢ GIÚP ============ */
const HELP_TABS=[["guide","📘","Hướng dẫn PFD","PFD guide"],["cad","📐","Hướng dẫn SimCAD","SimCAD guide"],["keys","⌨","Phím tắt & lệnh","Hotkeys & commands"],["faq","❓","Hỏi đáp (FAQ)","FAQ"],["about","ℹ","Về phần mềm","About"]];
let helpTab="";
const hk=s=>s.split("|").map(x=>`<span class="kbd">${escH(x)}</span>`).join(" ");
function escH(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function helpTable(title,rows){
 return `<h3>${title}</h3><table class="t helpk"><thead><tr><th>${_("Phím / lệnh","Key / command")}</th><th>${_("Tác dụng","Action")}</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${hk(r[0])}</td><td>${_(r[1],r[2])}</td></tr>`).join("")}</tbody></table>`;
}
const HK_PFD=[
 ["V","Công cụ chọn","Select tool"],["C","Công cụ nối ống (kéo từ chấm xanh cũng nối được)","Connect-pipe tool (dragging from a blue dot also connects)"],
 ["P","Thêm điểm nối ống tuỳ ý: bấm đúng vị trí trên thiết bị","Add a custom pipe connection point: click the exact spot on the device"],
 ["T","Thêm khung chữ","Add a text box"],["H|Space","Kéo khung nhìn (giữ Space rồi kéo; hoặc nút giữa chuột)","Pan the view (hold Space and drag; or middle mouse button)"],
 ["L","Vẽ đường","Draw a line"],["A","Vẽ mũi tên","Draw an arrow"],["B","Vẽ hộp","Draw a box"],["O","Vẽ elip / tròn","Draw an ellipse / circle"],
 ["Y","Vẽ đa tuyến (Enter hoặc chuột phải để kết thúc)","Draw a polyline (Enter or right-click to finish)"],["D","Bút vẽ tự do","Freehand pen"],
 ["Shift","Khi vẽ: giữ để vẽ thẳng / vuông / tròn đều","While drawing: hold for straight / square / true circle"],
 ["Alt","Giữ Alt và kéo chấm cam để dời điểm nối ống","Hold Alt and drag an orange dot to move a connection point"],
 ["Ctrl+A","Chọn tất cả","Select all"],["Ctrl+C|Ctrl+X|Ctrl+V","Sao chép / cắt / dán","Copy / cut / paste"],["Ctrl+D","Nhân bản","Duplicate"],
 ["←|↑|→|↓","Dịch đối tượng đang chọn 10 đơn vị (giữ Shift: 50)","Nudge the selection 10 units (hold Shift: 50)"],
 ["R","Xoay đối tượng đang chọn","Rotate the selection"],["F","Lật đối tượng đang chọn","Flip the selection"],["Q","Đổi kiểu vẽ (biến thể) của thiết bị","Cycle the drawing variant of a device"],
 ["Delete|Backspace","Xoá","Delete"],["F2","Sửa nhanh Tag (hoặc nội dung chữ)","Quick-edit the Tag (or the text content)"],
 ["Ctrl+Z|Ctrl+Y","Hoàn tác / làm lại (Ctrl+Shift+Z cũng là làm lại)","Undo / redo (Ctrl+Shift+Z also redoes)"],
 ["Ctrl+S","Lưu bản vẽ ra file JSON","Save the drawing as a JSON file"],["Ctrl+P","In / xuất PDF","Print / export PDF"],
 ["Ctrl+0","Vừa khung nhìn","Fit to view"],["+|-","Phóng to / thu nhỏ (cũng có thể lăn chuột; Shift+lăn = cuộn ngang)","Zoom in / out (mouse wheel works too; Shift+wheel = scroll sideways)"],
 ["Esc","Hủy thao tác, đóng cửa sổ, về công cụ chọn","Cancel, close dialogs, return to the select tool"],["?","Mở cửa sổ Thông tin / Trợ giúp này","Open this Info / Help window"]];
const HK_CAD=[
 ["Enter|Space","Chốt dòng lệnh / lặp lại lệnh trước khi dòng lệnh trống","Submit the command line / repeat the previous command when it is empty"],
 ["Esc","Hủy lệnh đang chạy; bấm lần nữa để bỏ chọn","Cancel the running command; press again to clear the selection"],
 ["Chuột phải","Giống Enter (kết thúc / xác nhận)","Same as Enter (finish / confirm)"],
 ["↑|↓","Lấy lại lệnh đã gõ trước đó trong dòng lệnh","Recall earlier commands in the command line"],
 ["F3","Bật / tắt bắt điểm đối tượng (đầu mút, trung điểm, tâm, giao điểm, gần nhất)","Toggle object snap (end, mid, centre, intersection, nearest)"],
 ["F8","Bật / tắt Ortho (chỉ ngang / dọc)","Toggle Ortho (horizontal / vertical only)"],
 ["F9","Bật / tắt bắt lưới","Toggle grid snap"],["F10","Bật / tắt Polar (bắt theo góc đặt trước)","Toggle Polar (snap to preset angles)"],
 ["Shift","Giữ để tạm đảo trạng thái Ortho","Hold to temporarily invert Ortho"],["Alt","Giữ để tắt mọi bắt điểm khi bấm","Hold to disable all snapping while clicking"],
 ["Ctrl+Z|Ctrl+Y","Hoàn tác / làm lại (hoặc gõ U / REDO)","Undo / redo (or type U / REDO)"],["Delete","Xoá đối tượng đang chọn","Delete the selection"],
 ["Ctrl+S","Lưu file .cad.json","Save a .cad.json file"],["Ctrl+P","In / xuất PDF vector","Print / export vector PDF"]];
const HK_CMD=[
 ["L|LINE","Đường thẳng","Line"],["PL|PLINE","Đa tuyến","Polyline"],["REC|RECT","Hình chữ nhật","Rectangle"],["C|CIRCLE","Đường tròn (tâm + bán kính)","Circle (centre + radius)"],
 ["A|ARC","Cung tròn qua 3 điểm (đầu, giữa, cuối)","Arc through 3 points (start, middle, end)"],["EL|ELLIPSE","Elip","Ellipse"],["T|TEXT","Chữ","Text"],["H|HATCH","Gạch mặt cắt: bấm vào vùng kín","Hatch: click inside a closed region"],
 ["D|DLI","Kích thước thẳng theo 2 điểm (ngang / dọc / xiên theo chuột)","Linear dimension from 2 points (horizontal / vertical / aligned by cursor)"],
 ["DAL","Kích thước song song (xiên)","Aligned dimension"],["DRA","Kích thước bán kính","Radius dimension"],["DDI","Kích thước đường kính","Diameter dimension"],
 ["M|MOVE","Di chuyển","Move"],["CO|CP|COPY","Sao chép","Copy"],["RO|ROTATE","Xoay","Rotate"],["SC|SCALE","Phóng tỷ lệ","Scale"],["MI|MIRROR","Đối xứng gương (hỏi có xoá bản gốc không)","Mirror (asks whether to delete the original)"],
 ["O|OFFSET","Song song cách một khoảng","Offset by a distance"],["E|ERASE","Xoá","Erase"],["X|EXPLODE","Phá khối (đa tuyến, hình chữ nhật → đoạn thẳng)","Explode (polyline, rectangle → segments)"],
 ["AR|ARRAY","Dãy: chữ nhật hoặc tròn","Array: rectangular or polar"],["TR|TRIM","Cắt tỉa tới đường biên (đoạn thẳng)","Trim to boundary edges (straight lines)"],["EX|EXTEND","Kéo dài tới đường biên (đoạn thẳng)","Extend to boundary edges (straight lines)"],
 ["Z|FIT","Vừa khung nhìn","Zoom to fit"],["U|UNDO|REDO","Hoàn tác / làm lại","Undo / redo"],["ORTHO|POLAR|SNAP|OSNAP","Bật / tắt các chế độ bắt điểm","Toggle snap modes"],
 ["LA|LAYER","Mở bảng lớp","Layers panel"],["V|SELECT|ALL","Công cụ chọn / chọn tất cả","Select tool / select all"],["PR|PRINT|PLOT","In / PDF","Print / PDF"],
 ["DXF|DXFIN","Xuất / nhập file DXF","Export / import DXF"],["CAL","Hiệu chuẩn ảnh nền bằng một khoảng đã biết","Calibrate the underlay with a known distance"],["DESC","Mô tả bản vẽ thành văn bản (đọc bằng TTS)","Describe the drawing as text (for TTS)"]];
const HK_COORD=[
 ["x,y","Toạ độ tuyệt đối theo đơn vị đang dùng, gốc ở góc dưới trái khổ giấy, Y hướng lên (vd 120,80)","Absolute coordinates in the current unit; origin at the bottom-left of the sheet, Y up (e.g. 120,80)"],
 ["@dx,dy","Toạ độ tương đối so với điểm trước (vd @50,0)","Relative to the previous point (e.g. @50,0)"],
 ["@d<góc","Cực tương đối: khoảng cách d, góc độ ngược chiều kim đồng hồ từ trục X (vd @100<45)","Relative polar: distance d, angle in degrees counter-clockwise from the X axis (e.g. @100<45)"],
 ["Số đơn","Chỉ một số: khoảng cách theo hướng con trỏ đang chỉ (kết hợp Ortho rất tiện)","A single number: distance along the direction the cursor points (very handy with Ortho)"]];
function guideCad(){
 const P=(vi,en)=>`<p>${_(vi,en)}</p>`;
 return `<h2>${_("Hướng dẫn SimCAD (Rev.0)","SimCAD guide (Rev.0)")}</h2>`+
 P("<b>Chuyển module:</b> dùng nút <b>PFD</b> / <b>SimCAD</b> ở đầu trang. Mỗi module có bản vẽ, lịch sử hoàn tác và tự lưu riêng; file JSON ghi rõ loại tài liệu nên mở file sẽ tự chuyển module.","<b>Switching modules:</b> use the <b>PFD</b> / <b>SimCAD</b> switch at the top. Each module has its own drawing, undo history and auto-save; a JSON file records its document type so opening it switches module automatically.")+
 P("<b>Tỷ lệ &amp; đơn vị thực:</b> trong ô “Thiết lập SimCAD” chọn đơn vị (mm, cm, m, in, ft) và tỷ lệ bản vẽ (vd 1:50). Bạn nhập kích thước thật; phần mềm tự đổi ra khổ giấy. Đổi tỷ lệ sẽ co giãn hình quanh tâm khổ giấy.","<b>Scale &amp; real units:</b> in the “SimCAD settings” box choose the unit (mm, cm, m, in, ft) and drawing scale (e.g. 1:50). You enter real sizes; the app converts to paper. Changing the scale rescales the geometry about the sheet centre.")+
 P("<b>Dòng lệnh (cách nhanh nhất, hợp với đọc màn hình):</b> chỉ cần gõ chữ ở bất kỳ đâu, con trỏ tự nhảy vào ô lệnh phía dưới. Gõ tên lệnh (vd <span class=\"kbd\">L</span>) rồi Enter; ô nhắc việc kế tiếp (“Điểm đầu”, “Điểm kế”…) hiện ngay cạnh và được ghi lên thanh trạng thái. Bạn có thể bấm chuột hoặc gõ toạ độ.","<b>Command line (fastest, and screen-reader friendly):</b> just start typing anywhere and the cursor jumps into the command box at the bottom. Type a command name (e.g. <span class=\"kbd\">L</span>) and press Enter; the next prompt (“First point”, “Next point”…) appears beside it and in the status bar. You may click or type coordinates.")+
 helpTable(_("Cách gõ toạ độ","Typing coordinates"),HK_COORD)+
 P("<b>Bắt điểm:</b> F3 bắt đối tượng (đầu mút, trung điểm, tâm, giao điểm, gần nhất — chọn loại trong thiết lập), F8 Ortho, F9 lưới, F10 Polar. Giữ Alt để tạm tắt. Dấu bắt hiện trên bản vẽ và đọc ở thanh trạng thái.","<b>Snapping:</b> F3 object snap (end, mid, centre, intersection, nearest — choose kinds in the settings), F8 Ortho, F9 grid, F10 Polar. Hold Alt to bypass. A marker shows on the drawing and the snap kind is announced in the status bar.")+
 P("<b>Lớp (layer):</b> bảng bên trái liệt kê lớp có màu, nét, độ dày; bật/tắt hiển thị, khoá, đặt lớp hiện hành. Có sẵn 0, OUT (đường bao), CEN (tâm), HID (khuất), DIM (kích thước), TXT (chữ), HAT (gạch). Xoá lớp thì đối tượng chuyển về lớp 0.","<b>Layers:</b> the left panel lists layers with colour, linetype and width; toggle visibility, lock, set the current layer. Defaults: 0, OUT (outline), CEN (centre), HID (hidden), DIM (dimensions), TXT (text), HAT (hatch). Deleting a layer moves its objects to layer 0.")+
 P("<b>Kích thước &amp; gạch mặt cắt:</b> lệnh D / DAL / DRA / DDI tạo kích thước tự động theo đơn vị thật; chọn kích thước để ghi đè chữ. Lệnh H gạch vùng kín (đường song song, lưới, hoặc đặc) với góc và bước chỉnh trong bảng thuộc tính.","<b>Dimensions &amp; hatching:</b> D / DAL / DRA / DDI create dimensions that follow the real unit; select one to override its text. H hatches a closed region (lines, cross or solid) with angle and spacing set in the properties panel.")+
 P("<b>Sửa hình:</b> gõ lệnh sửa (M, CO, RO, SC, MI, O, TR, EX, AR…), chọn đối tượng rồi Enter, sau đó chỉ điểm gốc và đích — hoặc gõ khoảng cách / toạ độ. Chọn trước đối tượng rồi gõ lệnh cũng được.","<b>Modifying:</b> type a modify command (M, CO, RO, SC, MI, O, TR, EX, AR…), select objects and press Enter, then give base and target points — or type a distance / coordinates. Selecting first and then typing the command also works.")+
 P("<b>DXF:</b> nút ⬇ DXF xuất bản R12 (kích thước và gạch mặt cắt được tách thành đường + chữ), ⬆ DXF nhập LINE, CIRCLE, ARC, (LW)POLYLINE, ELLIPSE, TEXT, MTEXT và nhận biết đơn vị ($INSUNITS). Các loại khác bị bỏ qua và được liệt kê.","<b>DXF:</b> ⬇ DXF exports R12 (dimensions and hatches are exploded into lines + text); ⬆ DXF imports LINE, CIRCLE, ARC, (LW)POLYLINE, ELLIPSE, TEXT, MTEXT and honours $INSUNITS. Other entity types are skipped and listed.")+
 P("<b>Ảnh nền / bản scan:</b> mở mục “Ảnh nền / bản scan” ở panel phải, chọn ảnh (JPG/PNG) hoặc PDF scan. Dùng lệnh <span class=\"kbd\">CAL</span> bấm 2 điểm trên ảnh rồi nhập khoảng cách thật để định tỷ lệ. Nút dò nét tự tạo đường thẳng ngang / dọc từ ảnh — bước đầu của việc vẽ lại bản scan, chưa nhận được đường chéo, cung, chữ, ký hiệu.","<b>Underlay / scans:</b> open “Underlay / scan” in the right panel and choose an image (JPG/PNG) or a scanned PDF. Use <span class=\"kbd\">CAL</span>: click 2 points on the image and enter the real distance to set the scale. The trace button creates horizontal / vertical lines from the image — a first step toward redrawing scans; diagonals, arcs, text and symbols are not detected yet.")+
 P("<b>In ấn:</b> dùng chung với PFD (khổ giấy, khung tên, lề, tỷ lệ, font). PDF xuất ra là vector, chữ nhúng font nên phóng to không vỡ.","<b>Printing:</b> shared with PFD (paper sizes, title blocks, margins, scale, fonts). The exported PDF is vector with embedded fonts, so it stays sharp at any zoom.");
}
function guideKeys(){
 return `<h2>${_("Phím tắt & lệnh","Hotkeys & commands")}</h2><p class="hint">${_("Bảng được sinh trực tiếp từ danh sách lệnh của phần mềm. Phím chỉ hoạt động khi con trỏ không nằm trong ô nhập liệu.","The tables are generated from the app's own command lists. Keys only work when the cursor is not in an input field.")}</p>`+
 helpTable(_("PFD — bàn phím","PFD — keyboard"),HK_PFD)+
 helpTable(_("SimCAD — điều khiển chung","SimCAD — general controls"),HK_CAD)+
 helpTable(_("SimCAD — lệnh (gõ vào dòng lệnh, không phân biệt hoa thường)","SimCAD — commands (type in the command line; case-insensitive)"),HK_CMD);
}
const FAQ=[
 ["Bản vẽ của tôi lưu ở đâu? Có bị mất khi đóng trình duyệt không?","Where is my drawing stored? Is it lost when I close the browser?","Phần mềm tự lưu liên tục trong bộ nhớ của trình duyệt (mỗi module một bản). Khi mở lại sẽ khôi phục. Tuy nhiên xoá dữ liệu duyệt web hoặc dùng chế độ ẩn danh sẽ mất — hãy bấm Lưu (Ctrl+S) để giữ bản sao file JSON.","The app auto-saves continuously in the browser (one copy per module) and restores it on reopening. Clearing site data or using a private window loses it — press Save (Ctrl+S) to keep a JSON copy."],
 ["Dữ liệu của tôi có bị gửi lên mạng không?","Is my data sent over the internet?","Không. Toàn bộ xử lý chạy trong trình duyệt của bạn, không có máy chủ nhận dữ liệu. Ngoại lệ duy nhất: khi đọc PDF scan loại hiếm mà bộ giải mã nội bộ không xử lý được, phần mềm có thể thử nạp thư viện pdf.js từ mạng; thư viện chỉ được tải về, không gửi file đi.","No. Everything runs inside your browser; no server receives your data. The only exception: for a rare scanned-PDF type the built-in decoder cannot read, the app may try to load the pdf.js library from the network — the library is only downloaded, your file is not uploaded."],
 ["Làm sao để PDF xuất ra là vector, không phải ảnh?","How do I get a vector PDF instead of an image?","Dùng In / PDF rồi bấm “Tải PDF”. File được tạo thẳng từ đường nét, chữ nhúng font Liberation nên phóng to bao nhiêu cũng nét. Nếu bản vẽ có ảnh nền thì chỉ ảnh đó là điểm ảnh, và chỉ in khi bạn bật “in cùng”.","Use Print / PDF and press “Download PDF”. The file is built from real paths with embedded Liberation fonts, so it stays sharp at any zoom. Only an underlay image (if you enable printing it) is raster."],
 ["Nút In không phản ứng?","The Print button does nothing?","Một số khung xem trước hoặc trình duyệt nhúng chặn cửa sổ in. Hãy dùng “Tải PDF” rồi in file PDF, hoặc mở file HTML trực tiếp bằng Chrome / Edge / Firefox.","Some embedded viewers block the print dialog. Use “Download PDF” and print that file, or open the HTML file directly in Chrome / Edge / Firefox."],
 ["Đổi SI ⇄ US có tự đổi số liệu không?","Does switching SI ⇄ US convert my values?","Có, phần mềm quy đổi gần đúng các đại lượng đã nhập kèm đơn vị (áp suất, nhiệt độ, lưu lượng, chiều dài…). Hãy kiểm tra lại số quan trọng. Trong Cài đặt có thể đặt đơn vị mặc định cho từng đại lượng và dùng bộ sẵn SI (m, °C, MMSCMD, barg…) hoặc US.","Yes, values entered with units are converted approximately (pressure, temperature, flow, length…). Double-check important numbers. In Settings you can set a default unit per quantity or use the SI (m, °C, MMSCMD, barg…) and US presets."],
 ["Ẩn tên thiết bị chỉ để lại Tag, hoặc ẩn chấm nối?","How do I show only the Tag, or hide the connection dots?","Ở panel phải, mục “Hiển thị”: bỏ chọn “Hiện tên / mô tả thiết bị (tắt = chỉ hiện tag)”, và chọn vị trí chú thích màu (legend) ở bất kỳ góc nào. Chấm nối ống: trong ⚙ Cài đặt, bỏ chọn “Luôn hiện mọi điểm nối ống” để chỉ thấy chúng khi cần nối.","In the right panel, “Display” section: untick “Show equipment names / descriptions (off = tag only)”, and place the colour legend in any corner. Connection dots: in ⚙ Settings untick “Always show all pipe connection points” so they only appear when you connect."],
 ["Tôi bị mù / khiếm thị, dùng thế nào cho tiện?","I am blind or vision-impaired. How can I work comfortably?","Phần mềm có nhãn ARIA, thông báo trạng thái đọc được bằng trình đọc màn hình, và nút “Mô tả” sinh văn bản mô tả toàn bộ bản vẽ. Với SimCAD, mọi thao tác đều làm được bằng bàn phím: gõ lệnh, gõ toạ độ, theo dõi thanh nhắc việc. Có chế độ tương phản cao và nút A− / A+ đổi cỡ chữ.","The app has ARIA labels, status messages for screen readers, and a “Describe” button that writes the whole drawing as text. In SimCAD everything can be done by keyboard: type commands and coordinates and follow the prompt line. There is a high-contrast mode and A− / A+ text size."],
 ["Nhập bản vẽ scan có tự vẽ lại không?","Does importing a scan redraw it automatically?","Mới là bước đầu: ảnh được đặt làm nền, bạn hiệu chuẩn tỷ lệ bằng CAL, và có thể dò tự động các đường ngang / dọc. Đường chéo, cung, chữ và ký hiệu chưa nhận dạng được. Scan PDF dạng CCITT / JBIG2 / JPX chưa giải mã được — hãy xuất ra JPG / PNG.","Only a first step so far: the image becomes an underlay, you calibrate the scale with CAL, and horizontal / vertical lines can be traced automatically. Diagonals, arcs, text and symbols are not recognised. CCITT / JBIG2 / JPX PDF scans cannot be decoded — export them as JPG / PNG."],
 ["File DXF mở trong AutoCAD bị mất kích thước hay gạch?","My DXF loses dimensions or hatches in AutoCAD?","Bản xuất là DXF R12 để tương thích rộng; kích thước và gạch mặt cắt được tách thành đường và chữ thường, nên nhìn đúng nhưng không còn là đối tượng kích thước / hatch. Chữ có dấu tiếng Việt được mã hoá \\U+XXXX.","The export is DXF R12 for wide compatibility; dimensions and hatches are exploded into plain lines and text, so they look right but are no longer dimension / hatch objects. Vietnamese accented text is encoded as \\U+XXXX."],
 ["Ống không tự nối vuông góc, thiết bị chồng lên nhau?","Pipes do not route neatly or devices overlap?","Dùng nhóm nút bố trí: Tránh chồng lấn, Giãn khoảng cách, Tự bố trí theo dòng, Đặt giữa trang. Nút 🕘 mở lịch sử có tên từng bước để quay lại nếu chưa ưng ý.","Use the layout buttons: Remove overlaps, Spread, Auto layout, Center on page. The 🕘 button opens a named history so you can step back."],
 ["Tôi muốn mở file cũ của Rev.trước?","Can I open files from earlier revisions?","Được. File JSON cũ được chuẩn hoá khi mở; trường nào chưa có sẽ lấy giá trị mặc định.","Yes. Older JSON files are normalised on load; missing fields get default values."]];
function guideFaq(){
 return `<h2>${_("Hỏi đáp thường gặp","Frequently asked questions")}</h2>`+FAQ.map((f,i)=>`<details class="faq"${i===0?" open":""}><summary>${_(f[0],f[1])}</summary><p>${_(f[2],f[3])}</p></details>`).join("");
}
function guideAbout(){
 const P=(vi,en)=>`<p>${_(vi,en)}</p>`;
 return `<h2>PFD Studio — Rev.5</h2><p class="hint">${_("Phiên bản 26.10.26 • một file HTML duy nhất, chạy ngoại tuyến, không cần cài đặt","Version 26.10.26 • a single HTML file, works offline, no installation")}</p>`+
 P("<b>Mục đích:</b> vẽ sơ đồ công nghệ (Process Flow Diagram) cho dầu khí — thiết bị, đường ống, quy cách ống, bảng dòng, hạ tầng chuỗi cung ứng khí — và (module SimCAD) vẽ CAD 2D đơn giản theo tỷ lệ thực, dùng chung khung giấy, in ấn và font.","<b>Purpose:</b> draw oil &amp; gas Process Flow Diagrams — equipment, piping, pipe specs, stream tables, gas supply-chain infrastructure — and (SimCAD module) simple 2D CAD at real scale, sharing sheets, printing and fonts.")+
 `<h3>${_("Tính năng chính","Main features")}</h3><ul>`+
 [["Thư viện thiết bị lớn, nhiều kiểu vẽ; tìm kiếm song ngữ","Large equipment library with many drawing variants; bilingual search"],
  ["Ống tự đi vuông góc; quy cách ống theo ASME / ISO; bảng dòng","Auto-orthogonal pipes; ASME / ISO pipe specs; stream table"],
  ["Khổ ISO A0–A4, ANSI A–E, ARCH D; nhiều mẫu khung tên; in nhiều trang","ISO A0–A4, ANSI A–E, ARCH D sheets; several title blocks; multi-page printing"],
  ["Đơn vị SI / US, đơn vị mặc định theo từng đại lượng","SI / US units with a default unit per quantity"],
  ["SimCAD: dòng lệnh, toạ độ gõ tay, bắt điểm, lớp, kích thước, gạch mặt cắt, DXF, ảnh nền","SimCAD: command line, typed coordinates, snapping, layers, dimensions, hatching, DXF, underlay"],
  ["Giao diện sáng / tối, VI / EN, cỡ chữ, tương phản cao; hỗ trợ trình đọc màn hình","Light / dark, VI / EN, text size, high contrast; screen-reader support"]].map(a=>`<li>${_(a[0],a[1])}</li>`).join("")+`</ul>`+
 `<h3>${_("Định dạng file","File formats")}</h3><ul><li>${_("Lưu / mở: JSON (.json cho PFD, .cad.json cho SimCAD)","Save / open: JSON (.json for PFD, .cad.json for SimCAD)")}</li><li>${_("Xuất: PDF vector (nhúng font), SVG, PNG, DXF R12 (SimCAD), bảng dòng CSV","Export: vector PDF (embedded fonts), SVG, PNG, DXF R12 (SimCAD), stream-table CSV")}</li><li>${_("Nhập: JSON, DXF, ảnh JPG / PNG, PDF scan (DCT / Flate)","Import: JSON, DXF, JPG / PNG images, scanned PDF (DCT / Flate)")}</li></ul>`+
 `<h3>${_("Giới hạn đã biết","Known limitations")}</h3><ul>`+
 [["Nhập scan mới là bước đầu: chỉ dò đường ngang / dọc.","Scan import is a first step: only horizontal / vertical lines are traced."],
  ["SimCAD là Rev.0: cắt tỉa / kéo dài chỉ với đoạn thẳng; DXF xuất là R12.","SimCAD is Rev.0: trim / extend work on straight lines only; DXF export is R12."],
  ["Quy đổi đơn vị là gần đúng; ký hiệu PFD đơn giản hoá, không thay thế bản vẽ phát hành theo tiêu chuẩn dự án.","Unit conversion is approximate; PFD symbols are simplified and do not replace formally issued drawings."]].map(a=>`<li>${_(a[0],a[1])}</li>`).join("")+`</ul>`+
 `<h3>${_("Giấy phép & quyền riêng tư","Licences & privacy")}</h3>`+
 P("Font nhúng trong PDF là họ Liberation (SIL Open Font License 1.1). Phần mềm không thu thập hay gửi dữ liệu đi; toàn bộ lưu trữ nằm trong trình duyệt của bạn.","PDF-embedded fonts are the Liberation family (SIL Open Font License 1.1). The app collects and sends no data; all storage stays in your browser.")+
 P("Bảng kích thước ống lấy từ ASME B36.10M / B36.19M, ISO 4200, ASTM B88, ISO 4427 — hãy đối chiếu bản gốc khi thiết kế thật.","Pipe dimension tables come from ASME B36.10M / B36.19M, ISO 4200, ASTM B88, ISO 4427 — verify against the originals for real design.");
}
function renderHelp(tab){
 if(tab)helpTab=tab;if(!helpTab)helpTab=(typeof cadOn==="function"&&cadOn())?"cad":"guide";
 const bar=$("hTabs");
 bar.innerHTML=HELP_TABS.map(t=>`<button class="btn htab${t[0]===helpTab?" on":""}" role="tab" aria-selected="${t[0]===helpTab}" data-t="${t[0]}">${t[1]} ${_(t[2],t[3])}</button>`).join("");
 bar.querySelectorAll("button").forEach(b=>b.onclick=()=>{renderHelp(b.dataset.t);$("hBody").scrollTop=0});
 const g=$("hGuide"),body=$("hBody");
 g.style.display=helpTab==="guide"?"block":"none";
 body.style.display=helpTab==="guide"?"none":"block";
 if(helpTab==="cad")body.innerHTML=guideCad();else if(helpTab==="keys")body.innerHTML=guideKeys();else if(helpTab==="faq")body.innerHTML=guideFaq();else if(helpTab==="about")body.innerHTML=guideAbout();
 body.classList.add("nt");
}
